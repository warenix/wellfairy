/* Offline-first SW. Bump CACHE to refresh. No external URLs cached.
 * Scheme pages (/s/*.html) are cached on demand (runtime), not precached.
 * admin.html is precached for the maintainer; benefits.staging.json is NOT
 * precached on purpose — the review queue must always read it fresh. */
const CACHE = 'hkbm-v102';
const ASSETS = ['./', './index.html', './admin.html', './404.html', './styles.css', './app.js', './admin.js', './manifest.webmanifest', './robots.txt', './llms.txt', './sitemap.xml', './art.svg', './data/benefits.json', './icons/icon.svg', './icons/icon-192.png', './icons/icon-512.png', './icons/maskable-512.png'];
self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  const url = new URL(e.request.url);
  if (url.origin !== location.origin) return; // never cache external
  e.respondWith(
    caches.match(e.request).then(hit => {
      const net = fetch(e.request).then(res => {
        if (res.ok) { const copy = res.clone(); caches.open(CACHE).then(c => c.put(e.request, copy)); }
        return res;
      }).catch(() => hit);
      return hit || net;
    })
  );
});
